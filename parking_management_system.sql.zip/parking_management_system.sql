-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2022 at 03:15 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parking_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_account`
--

CREATE TABLE `admin_account` (
  `Username` text NOT NULL,
  `Password` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_account`
--

INSERT INTO `admin_account` (`Username`, `Password`) VALUES
('Admin', '0192023a7bbd73250516f069df18b500');

-- --------------------------------------------------------

--
-- Table structure for table `employees_account`
--

CREATE TABLE `employees_account` (
  `Employee_ID` int(11) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(5000) NOT NULL,
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Age` int(100) NOT NULL,
  `Contact_No` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Province` text NOT NULL,
  `Municipality` text NOT NULL,
  `Barangay` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees_account`
--

INSERT INTO `employees_account` (`Employee_ID`, `Username`, `Password`, `Firstname`, `Lastname`, `Age`, `Contact_No`, `Email`, `Province`, `Municipality`, `Barangay`) VALUES
(1, 'employee1', 'employee1', 'johny', 'seen', 20, 912345678, 'employee1@gmail.com', 'Ilocos Norte', 'San Nicolas', 'Barangay 07 San Miguel'),
(3, 'employee2', 'af74a83ae0d5777401f86af4df941e98', 'dan', 'dan', 50, 12312312, 'employee2@gmail.com', 'ILOCOS NORTE', 'San Nicolas', 'Brgy 05 San Silvestre');

-- --------------------------------------------------------

--
-- Table structure for table `firstfloor_users`
--

CREATE TABLE `firstfloor_users` (
  `ID` int(20) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(5000) NOT NULL,
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Contact_Number` decimal(11,0) NOT NULL,
  `Plate_Number` varchar(20) NOT NULL,
  `VehicleType_ID` int(11) NOT NULL,
  `Parking_Slot` varchar(40) NOT NULL,
  `Status_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `firstfloor_users`
--

INSERT INTO `firstfloor_users` (`ID`, `Username`, `Password`, `Firstname`, `Lastname`, `Contact_Number`, `Plate_Number`, `VehicleType_ID`, `Parking_Slot`, `Status_ID`) VALUES
(2013, 'dan123', '2b645676db452cdb459794f79860a911', 'roldan', 'fiesta', '9122672340', 'xyz123', 1, '1A', 1);

-- --------------------------------------------------------

--
-- Table structure for table `parking_area`
--

CREATE TABLE `parking_area` (
  `Parking_ID` int(11) NOT NULL,
  `Parking_Slot` text NOT NULL,
  `Parking_Status` tinyint(1) DEFAULT NULL,
  `Parked_Vehicle` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parking_area`
--

INSERT INTO `parking_area` (`Parking_ID`, `Parking_Slot`, `Parking_Status`, `Parked_Vehicle`) VALUES
(1, '1A', 0, '4'),
(2, '1a', 1, 'Available'),
(3, '1B', 1, 'Available'),
(4, '1b', 1, 'Available'),
(5, '1C', 1, 'Available'),
(6, '1c', 1, 'Available'),
(7, '1D', 1, 'Available'),
(8, '1d', 1, 'Available'),
(9, '1E', 1, 'Available'),
(10, '1e', 1, 'Available'),
(11, '1F', 1, 'Available'),
(12, '1f', 1, 'Available'),
(13, '1G', 1, 'Available'),
(14, '1g', 1, 'Available'),
(15, '1H', 1, 'Available'),
(16, '1h', 1, 'Available'),
(17, '1I', 1, 'Available'),
(18, '1i', 1, 'Available'),
(19, '1J', 1, 'Available'),
(20, '1j', 1, 'Available'),
(21, '1K', 1, 'Available'),
(22, '1k', 1, 'Available'),
(23, '1L', 1, 'Available'),
(24, '1l', 1, 'Available'),
(25, '1M', 1, 'Available'),
(26, '1m', 1, 'Available'),
(27, '1N', 1, 'Available'),
(28, '1n', 1, 'Available'),
(29, '1O', 1, 'Available'),
(30, '1o', 1, 'Available'),
(31, '1P', 1, 'Available'),
(32, '1p', 1, 'Available'),
(33, '1Q', 1, 'Available'),
(34, '1q', 1, 'Available'),
(35, '1R', 1, 'Available'),
(36, '1r', 1, 'Available'),
(37, '1S', 1, 'Available'),
(38, '1s', 1, 'Available'),
(39, '1T', 1, 'Available'),
(40, '1t', 1, 'Available'),
(41, '2A', 1, 'Available'),
(42, '2a', 1, 'Available'),
(43, '2B', 1, 'Available'),
(44, '2b', 1, 'Available'),
(45, '2C', 1, 'Available'),
(46, '2c', 1, 'Available'),
(47, '2D', 1, 'Available'),
(48, '2d', 1, 'Available'),
(49, '2E', 1, 'Available'),
(50, '2e', 1, 'Available'),
(51, '2F', 1, 'Available'),
(52, '2f', 1, 'Available'),
(53, '2G', 1, 'Available'),
(54, '2g', 1, 'Available'),
(55, '2H', 1, 'Available'),
(56, '2h', 1, 'Available'),
(57, '2I', 1, 'Available'),
(58, '2i', 1, 'Available'),
(59, '2J', 1, 'Available'),
(60, '2j', 1, 'Available'),
(61, '2K', 1, 'Available'),
(62, '2k', 1, 'Available'),
(63, '2L', 1, 'Available'),
(64, '2l', 1, 'Available'),
(65, '2M', 1, 'Available'),
(66, '2m', 1, 'Available'),
(67, '2N', 1, 'Available'),
(68, '2n', 1, 'Available'),
(69, '2O', 1, 'Available'),
(70, '2o', 1, 'Available'),
(71, '2P', 1, 'Available'),
(72, '2p', 1, 'Available'),
(73, '2Q', 1, 'Available'),
(74, '2q', 1, 'Available'),
(75, '2R', 1, 'Available'),
(76, '2r', 1, 'Available'),
(77, '2S', 1, 'Available'),
(78, '2s', 1, 'Available'),
(79, '2T', 1, 'Available'),
(80, '2t', 1, 'Available'),
(81, '3A', 1, 'Available'),
(82, '3a', 1, 'Available'),
(83, '3B', 1, 'Available'),
(84, '3b', 1, 'Available'),
(85, '3C', 1, 'Available'),
(86, '3c', 1, 'Available'),
(87, '3D', 1, 'Available'),
(88, '3d', 1, 'Available'),
(89, '3E', 1, 'Available'),
(90, '3e', 1, 'Available'),
(91, '3F', 1, 'Available'),
(92, '3f', 1, 'Available'),
(93, '3G', 1, 'Available'),
(94, '3g', 1, 'Available'),
(95, '3H', 1, 'Available'),
(96, '3h', 1, 'Available'),
(97, '3I', 1, 'Available'),
(98, '3i', 1, 'Available'),
(99, '3J', 1, 'Available'),
(100, '3j', 1, 'Available'),
(101, '3K', 1, 'Available'),
(102, '3k', 1, 'Available'),
(103, '3L', 1, 'Available'),
(104, '3l', 1, 'Available'),
(105, '3M', 1, 'Available'),
(106, '3m', 1, 'Available'),
(107, '3N', 1, 'Available'),
(108, '3n', 1, 'Available'),
(109, '3O', 1, 'Available'),
(110, '3o', 1, 'Available'),
(111, '3P', 1, 'Available'),
(112, '3p', 1, 'Available'),
(113, '3Q', 1, 'Available'),
(114, '3q', 1, 'Available'),
(115, '3R', 1, 'Available'),
(116, '3r', 1, 'Available'),
(117, '3S', 1, 'Available'),
(118, '3s', 1, 'Available'),
(119, '3T', 1, 'Available'),
(120, '3t', 1, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `registered_users`
--

CREATE TABLE `registered_users` (
  `ID` int(11) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(5000) NOT NULL,
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Contact_No` decimal(11,0) NOT NULL,
  `Plate_No` varchar(30) NOT NULL,
  `VehicleType_ID` int(2) NOT NULL,
  `Parking_Slot` varchar(30) NOT NULL,
  `Status_ID` int(2) NOT NULL,
  `Time_In` text NOT NULL,
  `Time_Out` text DEFAULT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registered_users`
--

INSERT INTO `registered_users` (`ID`, `Username`, `Password`, `Firstname`, `Lastname`, `Contact_No`, `Plate_No`, `VehicleType_ID`, `Parking_Slot`, `Status_ID`, `Time_In`, `Time_Out`, `Date`) VALUES
(1933, 'dan123', '2b645676db452cdb459794f79860a911', 'roldan', 'fiesta', '9122672340', 'xyz123', 1, '1A', 2, '09:10:29 PM', '06:57:20 AM', '2022-06-06'),
(1948, 'qq', '099b3b060154898840f0ebdfb46ec78f', 'qq', 'qq', '12312312', 'qwe123', 1, '1A', 2, '07:42:15 AM', '08:42:48 AM', '2022-06-06'),
(1949, 'qq', '099b3b060154898840f0ebdfb46ec78f', 'qq', 'qq', '12312312', 'qwe123', 1, '1A', 2, '08:10:10 AM', '08:42:48 AM', '2022-06-06'),
(1950, 'qq', '099b3b060154898840f0ebdfb46ec78f', 'qq', 'qq', '12312312', 'qwe123', 1, '1A', 2, '08:11:30 AM', '08:42:48 AM', '2022-06-06'),
(1951, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, '2A', 2, '08:15:08 AM', '08:40:11 AM', '2022-06-06'),
(1952, 'rr', '514f1b439f404f86f77090fa9edc96ce', 'rr', 'rr', '9122672340', '12312', 1, '1a', 2, '08:17:25 AM', '08:19:01 AM', '2022-06-06'),
(1953, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, '2A', 2, '08:19:15 AM', '08:40:11 AM', '2022-06-06'),
(1954, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, '2A', 2, '08:21:38 AM', '08:40:11 AM', '2022-06-06'),
(1955, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, '2A', 2, '08:21:47 AM', '08:40:11 AM', '2022-06-06'),
(1956, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, '2A', 2, '08:21:54 AM', '08:40:11 AM', '2022-06-06'),
(1957, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, '2A', 2, '08:23:08 AM', '08:40:11 AM', '2022-06-06'),
(1958, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, '2A', 2, '08:23:20 AM', '08:40:11 AM', '2022-06-06'),
(1959, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, '2A', 2, '08:23:26 AM', '08:40:11 AM', '2022-06-06'),
(1960, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, '2A', 2, '08:23:32 AM', '08:40:11 AM', '2022-06-06'),
(1961, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, '2A', 2, '08:24:56 AM', '08:40:11 AM', '2022-06-06'),
(1962, 'RoldanFiesta123', '9924cf9146ba0c2552296af32b623a88', 'Jordan', 'Fiesta', '9293746582', 'US123', 1, '1A', 2, '08:34:26 AM', '08:57:24 AM', '2022-06-06'),
(1963, 'RoldanFiesta123', '9924cf9146ba0c2552296af32b623a88', 'Jordan', 'Fiesta', '9293746582', 'US123', 1, '1A', 2, '08:38:49 AM', '08:57:24 AM', '2022-06-06'),
(1964, 'RoldanFiesta123', '9924cf9146ba0c2552296af32b623a88', 'Jordan', 'Fiesta', '9293746582', 'US123', 1, '1A', 2, '08:55:23 AM', '08:57:24 AM', '2022-06-06'),
(1965, 'dan123', '2b645676db452cdb459794f79860a911', 'roldan', 'fiesta', '9122672340', 'xyz123', 1, '1A', 1, '09:07:09 AM', '', '2022-06-06');

-- --------------------------------------------------------

--
-- Table structure for table `sec_third_floor`
--

CREATE TABLE `sec_third_floor` (
  `ID` int(11) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(5000) NOT NULL,
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Contact_Number` decimal(11,0) NOT NULL,
  `Plate_Number` varchar(30) NOT NULL,
  `VehicleType_ID` int(11) NOT NULL,
  `Parking_Slot` varchar(80) NOT NULL,
  `Status_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `Status_ID` int(11) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`Status_ID`, `status`) VALUES
(1, 'In'),
(2, 'Out');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `Username` text NOT NULL,
  `Password` varchar(5000) NOT NULL,
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Contact_No` decimal(11,0) NOT NULL,
  `Plate_No` varchar(30) NOT NULL,
  `VehicleType_ID` int(20) NOT NULL,
  `Slot` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `Username`, `Password`, `Firstname`, `Lastname`, `Contact_No`, `Plate_No`, `VehicleType_ID`, `Slot`) VALUES
(4, 'dan123', '2b645676db452cdb459794f79860a911', 'roldan', 'fiesta', '9122672340', 'xyz123', 1, '1A'),
(5, 'user2', '7e58d63b60197ceb55a1c487989a3720', 'asd', 'asd', '9122672340', 'def456', 2, ''),
(6, 'qq', '099b3b060154898840f0ebdfb46ec78f', 'qq', 'qq', '12312312', 'qwe123', 1, 'none'),
(7, 'ww', 'ad57484016654da87125db86f4227ea3', 'ww', 'ww', '345', '234', 1, ''),
(8, 'ee', '08a4415e9d594ff960030b921d42b91e', 'ee', 'ee', '23', '23', 1, ''),
(9, 'rr', '514f1b439f404f86f77090fa9edc96ce', 'rr', 'rr', '9122672340', '12312', 1, 'none'),
(10, 't', 'e358efa489f58062f10dd7316b65649e', 't', 't', '345', 't', 1, ''),
(12, 'danxz123', 'b52c4793124758d8f9c0643fd0964f19', 'danxz', 'danxz', '1231231', '1231231asd', 1, ''),
(13, 'GG', '86d8d92aba9ecf9bbf89f69cb3e49588', 'GG', 'GG', '456', '456GG', 2, 'none'),
(14, 'kk', 'dc468c70fb574ebd07287b38d0d0676d', 'kk', 'kk', '9876543210', '098zxc', 2, ''),
(15, 'RoldanFiesta123', '9924cf9146ba0c2552296af32b623a88', 'Jordan', 'Fiesta', '9293746582', 'US123', 1, 'none');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `VehicleType_ID` int(11) NOT NULL,
  `Vehicle` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`VehicleType_ID`, `Vehicle`) VALUES
(1, 'Two-Wheeled'),
(2, 'Four-Wheeled');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees_account`
--
ALTER TABLE `employees_account`
  ADD PRIMARY KEY (`Employee_ID`);

--
-- Indexes for table `firstfloor_users`
--
ALTER TABLE `firstfloor_users`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `parking_area`
--
ALTER TABLE `parking_area`
  ADD PRIMARY KEY (`Parking_ID`);

--
-- Indexes for table `registered_users`
--
ALTER TABLE `registered_users`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sec_third_floor`
--
ALTER TABLE `sec_third_floor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`VehicleType_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employees_account`
--
ALTER TABLE `employees_account`
  MODIFY `Employee_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `firstfloor_users`
--
ALTER TABLE `firstfloor_users`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2014;

--
-- AUTO_INCREMENT for table `parking_area`
--
ALTER TABLE `parking_area`
  MODIFY `Parking_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `registered_users`
--
ALTER TABLE `registered_users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1966;

--
-- AUTO_INCREMENT for table `sec_third_floor`
--
ALTER TABLE `sec_third_floor`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `VehicleType_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
